<?php

namespace WpRefs\API;
/*
usage:

use function WpRefs\API\get_revisions;

*/

$user_agent = "WikiProjectMed Translation Dashboard/1.0 (https://mdwiki.toolforge.org/; tools.mdwiki@toolforge.org)";

function submitAPI(array $params, string $end_point)
{
    global $user_agent;
    // ---
    $ch = curl_init($end_point);

    // Set options
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));

    // Execute the request
    $response = curl_exec($ch);

    // Check for errors
    // if (curl_errno($ch)) { echo 'Error:' . curl_error($ch); }

    // Close the curl handle
    curl_close($ch);

    // Decode the JSON response
    $json = json_decode($response, true);

    return $json;
}

function get_revisions(string $title, string $lang): array
{
    $params = [
        "action" => "query",
        "format" => "json",
        "prop" => "revisions",
        "titles" => $title,
        "formatversion" => "2",
        "rvprop" => "comment|user|timestamp",
        "rvdir" => "newer",
        "rvlimit" => "max",
    ];

    $rvContinue = "x"; // Initial value for continuation parameter
    $revisions = []; // Array to store revisions
    $endPoint = "https://$lang.wikipedia.org/w/api.php";

    // Loop to fetch revisions with continuation
    while ($rvContinue !== "") {
        if ($rvContinue !== "x") {
            $params["rvcontinue"] = $rvContinue;  // Add continuation parameter
        }

        $json = submitAPI($params, $endPoint); // Send the request

        // Check for valid JSON response
        if (!$json || !is_array($json)) {
            echo "Error: Invalid JSON response.\n";
            break;
        }

        // Extract continuation parameter and pages data
        $rvContinue = isset($json['continue']['rvcontinue']) ? $json['continue']['rvcontinue'] : "";
        $pages = isset($json['query']['pages']) ? $json['query']['pages'] : [[]];

        // Iterate through page revisions and add them to the collection
        foreach ($pages as $page) {
            $revisions = array_merge($revisions, $page['revisions'] ?? []);  // Use array_merge for efficient concatenation
        }
    }

    return $revisions;
}
