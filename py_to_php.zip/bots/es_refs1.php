<?php

namespace WpRefs\Bots\es_refs1;
/*
usage:

use function WpRefs\Bots\es_refs1\get_refs;
*/

// use function WikiParse\Template\getTemplates;
use function WikiParse\Citations\getCitations;

function get_refs(string $text): array
{
    // ---
    $new_text = $text;
    // ---
    $refs = [];
    // ---
    $citations = getCitations($text);
    // ---
    $new_text = $text;
    // ---
    $numb = 0;
    // ---
    foreach ($citations as $key => $citation) {
        // ---
        $cite_text = $citation->getCiteText();
        // ---
        $cite_contents = $citation->getTemplate();
        // ---
        $cite_attrs = $citation->getOptions();
        $cite_attrs = $cite_attrs ? trim($cite_attrs) : "";
        // ---
        if (empty($cite_attrs)) {
            $numb += 1;
            $name = "autogen_" . $numb;
            $cite_attrs = "name='$name'";
        }
        // ---
        $refs[$cite_attrs] = $cite_contents;
        // ---
        // echo "\n$cite_attrs\n";
        // ---
        $cite_newtext = "<ref $cite_attrs />";
        // ---
        $new_text = str_replace($cite_text, $cite_newtext, $new_text);
    }
    // ---
    return [
        "refs" => $refs,
        "new_text" => $new_text,
    ];
}
