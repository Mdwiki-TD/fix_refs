<?php

namespace WpRefs\Bots\es_refs;
/*
usage:

use function WpRefs\Bots\es_refs\mv_es_refs;
*/

use function WikiParse\Template\getTemplates;
use function WpRefs\Bots\es_refs1\get_refs;
use function WikiParse\Reg_Citations\getShortCitations;

function check_short_refs($line)
{
    // ---
    $shorts = getShortCitations($line);
    // ---
    foreach ($shorts as $short) {
        $line = str_replace($short["tag"], "", $line);
    }
    // ---
    // remove \n+
    $line = preg_replace("/\n+/", "\n", $line);
    // ---
    return $line;
};

function make_line(array $refs): string
{
    $line = "\n";

    foreach ($refs as $name => $ref) {
        $la = '<ref ' . trim($name) . '>' . $ref . '</ref>' . "\n";
        $line .= $la;
    }

    $line = trim($line);

    return $line;
}

function add_line_to_temp($line, $text)
{
    // ---
    $temps_in = getTemplates($text);
    // ---
    // echo "lenth temps_in:" . count($temps_in) . "\n";
    // ---
    $new_text = $text;
    // ---
    $temp_already_in = false;
    // ---
    foreach ($temps_in as $temp) {
        // ---
        $name = $temp->getStripName();
        // ---
        // echo "\n$name\n";
        // ---
        $old_text_template = $temp->getTemplateText();
        // ---
        if (!in_array(strtolower($name), ["reflist", "listaref"])) {
            continue;
        };
        // ---
        // echo "\n$name\n";
        // ---
        $refn_param = $temp->getParameter("refs");
        // ---
        if ($refn_param && !empty($refn_param)) {
            $refn_param = check_short_refs($refn_param);
            // ---
            $line = trim($refn_param) . "\n" . trim($line);
        };
        // ---
        $temp->setParameter("refs", "\n" . trim($line) . "\n");
        // ---
        $temp_already_in = true;
        // ---
        $new_text_str = $temp->toString();
        // ---
        $new_text = str_replace($old_text_template, $new_text_str, $new_text);
        // ---
        break;
    };
    // ---
    if (!$temp_already_in) {
        $section_ref = "\n== Referencias ==\n{{listaref|refs=\n$line\n}}";
        $new_text .= $section_ref;
    }
    // ---
    return $new_text;
}

function mv_es_refs(string $text): string
{
    // ---
    if (empty($text)) {
        // echo "text is empty";
        return $text;
    }
    // ---
    $refs = get_refs($text);
    // ---
    $new_lines = make_line($refs['refs']);
    // ---
    $new_text = $refs['new_text'];
    // ---
    $new_text = add_line_to_temp($new_lines, $new_text);
    // ---
    return $new_text;
}
