<?php

namespace WpRefs\DelDuplicateRefs;

/*
Usage:

use function WpRefs\DelDuplicateRefs\remove_Duplicate_refs;

*/

use function WikiParse\Reg_Citations\get_full_refs;
use function WikiParse\Reg_Citations\getShortCitations;
use function WikiParse\Citations\getCitations;

function get_html_attribute_value(string $text, string $param): string
{
    if (empty($text)) {
        return '';
    }

    // Case-insensitive regular expression for attribute extraction
    $pattern = sprintf('/(?i)%s\s*=\s*[\'"]?(?P<%s>[^\'" >]+)[\'"]?/', $param, $param);
    $match = preg_match($pattern, $text, $matches);

    if ($match) {
        return $matches[$param];
    }

    return '';
}
function remove_Duplicate_refs(string $text): string
{
    // ---
    $new_text = $text;
    // ---
    $refs = [];
    // ---
    $citations = getCitations($text);
    // ---
    $new_text = $text;
    // ---
    $numb = 0;
    // ---
    foreach ($citations as $key => $citation) {
        // ---
        $cite_text = $citation->getCiteText();
        // ---
        $cite_contents = $citation->getTemplate();
        // ---
        $cite_attrs = $citation->getOptions();
        $cite_attrs = $cite_attrs ? trim($cite_attrs) : "";
        // ---
        if (empty($cite_attrs)) {
            $numb += 1;
            $name = "autogen_" . $numb;
            $cite_attrs = "name='$name'";
        }
        // ---
        $cite_newtext = "<ref $cite_attrs />";
        // ---
        echo "\n$cite_newtext";
        // ---
        if (isset($refs[$cite_attrs])) {
            // ---
            $new_text = str_replace($cite_text, $cite_newtext, $new_text);
        } else {
            $refs[$cite_attrs] = $cite_newtext;
        };
    }
    // ---
    /*foreach ($refs as $key => $value) {
        // ---
        $short_ref = "<ref $key />";
        // ---
        $long_ref = "<ref $key>$value</ref>";
        // ---
        // $new_text = str_replace($short_ref, $long_ref, $new_text);
        // ---
        $new_text = preg_replace('/' . preg_quote($short_ref, '/') . '/', $long_ref, $new_text, 1);
    }*/
    // ---
    return $new_text;
}
