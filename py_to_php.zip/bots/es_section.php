<?php

namespace WpRefs\Bots\es_section;
/*
usage:

use function WpRefs\Bots\es_section\add_section;
use function WpRefs\Bots\es_section\make_template;
*/

use function WpRefs\API\get_revisions;

$es_months_tab = [
    "1" => "enero",
    "2" => "febrero",
    "3" => "marzo",
    "4" => "abril",
    "5" => "mayo",
    "6" => "junio",
    "7" => "julio",
    "8" => "agosto",
    "9" => "septiembre",
    "10" => "ctubre",
    "11" => "noviembre",
    "12" => "diciembre",
];


function make_date($timestamp)
{
    global $es_months_tab;

    // Split timestamp at 'T' to separate date from time (if present)
    $date = explode("T", $timestamp)[0];
    $date = trim($date);  // Remove leading/trailing whitespace

    // Regular expression to match YYYY-MM-DD format
    $pattern = "/^(?<y>\d{4})-(?<m>\d{2})-(?<d>\d{2})$/";
    $match = preg_match($pattern, $date, $matches);

    if (!$match) {
        return $timestamp;  // Return original timestamp if parsing fails
    }

    // Extract day, month, and year from matched groups
    $day = $matches['d'];
    $month = $matches['m'];
    $year = $matches['y'];

    // if $month starts with 0 remove it
    if (strpos($month, "0") === 0) {
        $month = substr($month, 1);
    }

    // Retrieve month name from translation array or use numeric value if not found
    $monthName = isset($es_months_tab[$month]) ? $es_months_tab[$month] : $month;

    // Format the date string
    return "$day de $monthName de $year";
}

// echo make_date("2023-02-28T14:01:49Z");

function get_comment_and_timestamp($title)
{
    // Assuming you have a function to fetch revisions, similar to MediaWiki API
    $revisions = get_revisions($title, "es");


    $timestamp = ""; // 2023-02-28T14:01:49Z
    $comment = ""; // Creado al traducir la página «[[:en:Special:Redirect/revision/1138582883|User:Mr. Ibrahem/Herpes labialis]]
    # ---
    foreach ($revisions as $revision) {
        $timestamp = $revision['timestamp'] ?? "";
        $comment = strtolower($revision['comment'] ?? "");

        if (stripos($comment, "#mdwikicx") !== false && stripos($comment, ":mdwiki:special:redirect/revision/") !== false) {
            break;
        }
    }
    # ---
    return [
        "timestamp" => $timestamp,
        "comment" => $comment
    ];
}

function make_template($title)
{
    echo "make_template:$title\n";

    // Extract comment and timestamp (implementation depends on your environment)
    $tab = get_comment_and_timestamp($title);  // Replace with your logic
    // var_dump($tab);
    // Check if extraction worked
    if (!isset($tab['timestamp']) || !isset($tab['comment'])) {
        return "";
    }

    $timestamp = $tab['timestamp'];
    $comment = $tab['comment'];

    $pageTitle = "";
    $oldId = "";

    // Extract page title and old ID from comment using regular expression
    $match = preg_match("/revision\/(\d+)\|([^\]]+?)\]\]/", $comment, $matches);
    if ($match) {
        $oldId = $matches[1];
        $pageTitle = $matches[2];
    }

    // Convert timestamp to formatted date (implementation depends on your environment)
    $date = make_date($timestamp);  // Replace with your logic

    // Check if title and date are valid
    if (empty($pageTitle) || empty($date)) {
        return "";
    }

    // Build the template section
    $section = "\n==Enlaces externos==\n";
    $section .= "{{Traducido ref|mdwiki|$pageTitle|oldid=$oldId|trad=|fecha=$date}}\n";

    return $section;
}

function add_section($text, $title)
{
    echo "add_section";
    // Check for presence of the "{{Traducido ref}}" pattern (case-insensitive)
    if (preg_match("/\{\{\s*Traducido ref\s*\|/i", $text)) {
        return $text;
    }

    $temp = make_template($title);

    echo "\ntemp: $temp\n";

    // Search for existing "==Enlaces externos==" section
    $match = preg_match("/==\s*Enlaces\s*externos\s*==/i", $text, $matches);

    if ($match) {
        $existing_section = $matches[0];
        $text = str_replace($existing_section, $temp, $text);
    } else {
        // If not found, append the new section at the end
        $text .= $temp;
    }

    return $text;
}
