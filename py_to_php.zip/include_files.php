<?php


include_once __DIR__ . '/WikiParse/include_it.php';

include_once __DIR__ . '/api.php';

include_once __DIR__ . '/WikiParse/Template.php';

include_once __DIR__ . '/bots/remove_duplicate_refs.php';
include_once __DIR__ . '/bots/expend_refs.php';
include_once __DIR__ . '/bots/es_months.php';
include_once __DIR__ . '/bots/es_refs.php';
include_once __DIR__ . '/bots/es_refs1.php';
include_once __DIR__ . '/bots/es_section.php';
include_once __DIR__ . '/bots/fix_pt_months.php';
include_once __DIR__ . '/bots/txtlib2.php';

include_once __DIR__ . '/es.php';
include_once __DIR__ . '/infobox.php';
include_once __DIR__ . '/infobox2.php';
include_once __DIR__ . '/wpref_text.php';
