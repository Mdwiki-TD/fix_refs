<?php

namespace WpRefs\wpref_text;

/*
usage:

use function WpRefs\wpref_text\fix_page;

*/

use function WpRefs\Infobox\Expend_Infobox;
use function WpRefs\FixPtMonth\pt_months;
use function WpRefs\ES\fix_es;
use function WpRefs\DelDuplicateRefs\remove_Duplicate_refs;

function move_dots_text($newtext, $lang)
{
    // ---
    echo "move_dots_text\n";
    // ---
    $dot = "(\.|\,)";
    // ---
    if ($lang == "zh") {
        $dot = "(。)";
    }
    // ---
    $regline = "((?:\s*<ref[\s\S]+?(?:<\/ref|\/)>)+)";
    // ---
    $pattern = "/" . $dot . "\s*" . $regline . "/m";
    $replacement = "$2$1";
    // ---
    echo "\n$pattern\n";
    // ---
    $newtext = preg_replace($pattern, $replacement, $newtext);
    // ---
    return $newtext;
}

function add_lang_en($text)
{
    // ---
    // Match references
    $REFS = "/(?is)(?P<pap><ref[^>\/]*>)(?P<ref>.*?<\/ref>)/";
    // ---
    if (preg_match_all($REFS, $text, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $match) {
            $pap = $match['pap'];
            $ref = $match['ref'];
            // ---
            if (!trim($ref)) {
                continue;
            }
            // ---
            if (preg_replace("/\|\s*language\s*\=\s*\w+/", "", $ref) != $ref) {
                continue;
            }
            // ---
            $ref2 = preg_replace("/(\|\s*language\s*\=\s*)(\|\}\})/", "$1en$2", $ref);
            // ---
            if ($ref2 == $ref) {
                $ref2 = str_replace("}}</ref>", "|language=en}}</ref>", $ref);
            }
            // ---
            if ($ref2 != $ref) {
                $text = str_replace($pap . $ref, $pap . $ref2, $text);
            }
        }
    }
    // ---
    return $text;
}

function fix_page($text, $title, $move_dots, $infobox, $add_en_lang, $lang)
{
    // ---
    // print_s("fix page: $title, move_dots:$move_dots, expend_infobox:$infobox");
    // ---
    if ($infobox) {
        echo "Expend_Infobox\n";
        $text = Expend_Infobox($text, $title, "");
    }
    // ---
    // $text = remove_False_code($text);
    // ---
    $text = remove_Duplicate_refs($text);
    // ---
    if ($move_dots) {
        echo "move_dots\n";
        $text = move_dots_text($text, $lang);
    }
    // ---
    if ($add_en_lang) {
        echo "add_en_lang\n";
        $text = add_lang_en($text);
    }
    // ---
    if ($lang === "pt") {
        $text = pt_months($text);
    }
    // ---
    if ($lang === "es") {
        $text = fix_es($text, $title);
    }
    // ---
    return $text;
}
