<?php


include_once __DIR__ . '/parsewiki/DataModel/Citation.php';
include_once __DIR__ . '/parsewiki/DataModel/ExternalLink.php';
include_once __DIR__ . '/parsewiki/DataModel/InternalLink.php';
include_once __DIR__ . '/parsewiki/DataModel/Table.php';
include_once __DIR__ . '/parsewiki/DataModel/Template.php';

include_once __DIR__ . '/parsewiki/ParserCategorys.php';
include_once __DIR__ . '/parsewiki/ParserCitations.php';
include_once __DIR__ . '/parsewiki/ParserExternalLinks.php';
include_once __DIR__ . '/parsewiki/ParserInternalLinks.php';
include_once __DIR__ . '/parsewiki/ParserTemplate.php';
include_once __DIR__ . '/parsewiki/ParserTemplates.php';

include_once __DIR__ . '/Template.php';
include_once __DIR__ . '/Citations_reg.php';
include_once __DIR__ . '/Citations.php';
include_once __DIR__ . '/Category.php';
