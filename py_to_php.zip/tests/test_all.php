<?php
/*
php I:\mdwiki\mdwiki\public_html\fixwikirefs\wprefs\tests\test_all.php
*/
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once __DIR__ . '/../bot.php';

use function WpRefs\FixPage\fix_page_here;

$test_files = [];

$test_text_dir = __DIR__ . "/test_all/";
// list of folders in $test_text_dir

$test_text_langs = array_diff(scandir($test_text_dir), ["..", "."]);

foreach ($test_text_langs as $lang) {
    $test_files[] = [
        "old" => $test_text_dir . $lang . "/old.txt",
        "new" => $test_text_dir . $lang . "/new.txt",
        "title" => $test_text_dir . $lang . "/title.txt",
        "lang" => str_replace("_", "", $lang),
    ];
}

echo "test_files:\n";

foreach ($test_files as $test) {
    $lang = $test["lang"];
    echo "\n__________ $lang __________\n\n";
    $old = file_get_contents($test["old"]);
    $new = file_get_contents($test["new"]);
    $title = trim(file_get_contents($test["title"]) ?? "");

    $fixed_text = fix_page_here($old, $title, $test["lang"]);

    if ($fixed_text == $new) {
        echo "fixed okay!";
        file_put_contents($test["new"] . ".fixed", $fixed_text);
    } elseif ($fixed_text == $old) {
        echo "fixed_text == old text!";
    } else {
        echo "fixed error!:\n\n";
        // echo $fixed_text;
        file_put_contents($test["new"] . ".fixed", $fixed_text);
    }
}
