<?php
/*
php I:\mdwiki\mdwiki\public_html\fixwikirefs\wprefs\tests\test_params.php
*/
ini_set("display_errors", 1);
ini_set("display_startup_errors", 1);
error_reporting(E_ALL);

$parameters =  [
    "vauthors" => "Dowd SE, Gerba CP, Pepper IL",
    "title" => "Confirmation",
    "journal" => "Applied and Environmental Microbiology",
    "volume" => "64",
    "issue" => "9",
    "bibcode" => "1998ApEnM..64.3332D"
];

function changeParameterName(string $old, string $new, $parameters): array
{
    $newParameters = [];
    foreach ($parameters as $k => $v) {
        if ($k === $old) {
            $k = $new;
        };
        $newParameters[$k] = $v;
    }
    return $newParameters;
};

$new = changeParameterName("title", "newtitle", $parameters);

print_r($new);
