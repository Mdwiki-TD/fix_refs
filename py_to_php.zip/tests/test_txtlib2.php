<?php
/*

php I:\mdwiki\mdwiki\public_html\fixwikirefs\wprefs\tests\test_txtlib2.php

*/
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once __DIR__ . '/../include_files.php';

use function WpRefs\Bots\TxtLib2\extract_templates_and_params;

$text = file_get_contents(__DIR__ . "/texts/txtlib2.txt");

$data = extract_templates_and_params($text);

// dump data to json file

file_put_contents(__DIR__ . "/texts/txtlib2.json", json_encode($data, JSON_PRETTY_PRINT));
