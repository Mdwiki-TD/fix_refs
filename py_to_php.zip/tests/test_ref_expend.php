<?php
/*

php I:\mdwiki\mdwiki\public_html\fixwikirefs\wprefs\tests\test_ref_expend.php

*/
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once __DIR__ . '/../include_files.php';

use function WpRefs\ExpendRefs\refs_expend_work;

// Replace with actual file paths
$file1 = __DIR__ . '/texts/expend.txt';
$file2 = __DIR__ . '/texts/expend_fixed.txt';

$text = file_get_contents($file1);

$new_text = refs_expend_work($text);

file_put_contents($file2, $new_text);
