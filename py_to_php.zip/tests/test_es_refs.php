<?php
/*

php I:\mdwiki\mdwiki\public_html\fixwikirefs\wprefs\tests\test_es_refs.php

*/
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once __DIR__ . '/../include_files.php';

use function WpRefs\Bots\es_refs\mv_es_refs;
use function WpRefs\Bots\es_refs\make_line;

// Replace with actual file paths
$file1 = __DIR__ . '/texts/es_mv.txt';
$file2 = __DIR__ . '/texts/es_mv_fixed.txt';

$text = file_get_contents($file1);

$new_text = mv_es_refs($text);

file_put_contents($file2, $new_text);

exit;


$refs = [
    "ref1" => "Reference 1",
    "ref2" => "Reference 2",
    "ref3" => "Reference 3",
];

$line = make_line($refs);

echo $line;
