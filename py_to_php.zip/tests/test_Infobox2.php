<?php
/*
php I:\mdwiki\mdwiki\public_html\fixwikirefs\wprefs\tests\test_Infobox2.php
*/
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once __DIR__ . '/../include_files.php';

use function WpRefs\Infobox2\make_tempse;
use function WpRefs\Infobox2\expend_new;

$text = file_get_contents(__DIR__ . "/texts/infobox2.txt");


$new_text = expend_new($text);

file_put_contents(__DIR__ . "/texts/infobox2_new.txt", $new_text);


$page = file_get_contents(__DIR__ . "/texts/page.txt");

$data = make_tempse($page);

file_put_contents(__DIR__ . "/texts/page.json", json_encode($data, JSON_PRETTY_PRINT));
