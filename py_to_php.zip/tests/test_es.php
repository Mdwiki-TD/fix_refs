<?php
/*
php I:\mdwiki\mdwiki\public_html\fixwikirefs\wprefs\tests\test_es.php
*/
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once __DIR__ . '/../include_files.php';

use function WpRefs\ES\fix_temps;
use function WpRefs\ES\fix_es;

$test_texts = [
    [
        "old" => "hi!. <ref name=Doed1998>{{cite journal |vauthors=Dowd SE, Gerba CP, Pepper IL |title=Confirmation of the Human-Pathogenic Microsporidia Enterocytozoon bieneusi, Encephalitozoon intestinalis, and Vittaforma corneae in Water |journal=Applied and Environmental Microbiology |volume=64 |issue=9 |pages=3332–5 |year=1998 |pmid=9726879 |pmc=106729 |doi= 10.1128/AEM.64.9.3332-3335.1998|bibcode=1998ApEnM..64.3332D }}</ref>yemen",
        "new" => "hi!. <ref name=Doed1998>{{cita publicación|vauthors = Dowd SE, Gerba CP, Pepper IL|título = Confirmation of the Human-Pathogenic Microsporidia Enterocytozoon bieneusi, Encephalitozoon intestinalis, and Vittaforma corneae in Water|journal = Applied and Environmental Microbiology|volumen = 64|issue = 9|páginas = 3332–5|año = 1998|pmid = 9726879|pmc = 106729|doi = 10.1128/AEM.64.9.3332-3335.1998|bibcode = 1998ApEnM..64.3332D}}</ref>yemen"
    ],
    [
        "old" => "hi!. <ref name=Doed1998>{{cite journal|vauthors=Dowd SE|title=Confirmation |journal=Applied |volume=64 |issue=9 |pages=3332–5 |year=1998 |pmid=9726879 |pmc=106729 |doi= 10|bibcode=1}}</ref> dodo",
        "new" => "hi!. <ref name=Doed1998>{{cita publicación|vauthors = Dowd SE|título = Confirmation|journal = Applied|volumen = 64|issue = 9|páginas = 3332–5|año = 1998|pmid = 9726879|pmc = 106729|doi = 10|bibcode = 1}}</ref> dodo"
    ],
    [
        "old" => "{{cite journal|vauthors=Dowd SE|title=Confirmation |journal=Applied |volume=64 |issue=9 |pages=3332–5 |year=1998 |pmid=9726879 |pmc=106729 |doi= 10|bibcode=1|url-status=dead}}",
        "new" => "{{cita publicación|vauthors = Dowd SE|título = Confirmation|journal = Applied|volumen = 64|issue = 9|páginas = 3332–5|año = 1998|pmid = 9726879|pmc = 106729|doi = 10|bibcode = 1}}"
    ],
    [
        "old" => "{{cite journal|vauthors=Dowd SE|title=Confirmation|url-status=dead}}{{cite web |title=CDC - DPDx - Microsporidiosis |url=https://www.cdc.gov/dpdx/microsporidiosis/index.html |website=www.cdc.gov |accessdate=11 December 2024 |language=en-us |date=29 May 2019}}",
        "new" => "{{cita publicación|vauthors = Dowd SE|título = Confirmation}}{{cita web|título = CDC - DPDx - Microsporidiosis|url = https://www.cdc.gov/dpdx/microsporidiosis/index.html|sitioweb = www.cdc.gov|fechaacceso = 11 December 2024|idioma = en-us|fecha = 29 May 2019}}"
    ],
    [
        "old" => "<ref>{{cite journal |date=July 25, 1975}}</ref>",
        "new" => "<ref>{{cita publicación|fecha = 25 de julio de 1975}}</ref>"
    ],
];

foreach ($test_texts as $test) {
    $old = $test["old"];
    $new = $test["new"];

    // $fixed_text = fix_temps($old);
    $fixed_text = fix_es($old, "test!");

    if ($fixed_text == $new) {
        echo "fixed okay!";
    } elseif ($fixed_text == $old) {
        echo "fixed_text == old text!";
    } else {
        echo "fixed error!:\n\n";
        echo $fixed_text;
    }
    echo "\n\n____________________\n\n";
}


$test_files = [
    [
        "old" => __DIR__ . "/texts/es_old.txt",
        "new" => __DIR__ . "/texts/es_new.txt",
    ],
];

echo "test_files:\n";

foreach ($test_files as $test) {
    $old = file_get_contents($test["old"]);
    $new = file_get_contents($test["new"]);

    // $fixed_text = fix_temps($old);
    $fixed_text = fix_es($old, "test!");

    if ($fixed_text == $new) {
        echo "fixed okay!";
    } elseif ($fixed_text == $old) {
        echo "fixed_text == old text!";
    } else {
        echo "fixed error!:\n\n";
        // echo $fixed_text;
        file_put_contents($test["new"] . ".fixed", $fixed_text);
    }
    echo "\n\n____________________\n\n";
}
