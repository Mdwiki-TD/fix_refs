<?php
/*

php I:\mdwiki\mdwiki\public_html\fixwikirefs\wprefs\tests\test_del_dup.php

*/
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once __DIR__ . '/../include_files.php';

use function WpRefs\DelDuplicateRefs\remove_Duplicate_refs;

// Replace with actual file paths
$file1 = __DIR__ . '/texts/del_dup.txt';
$file2 = __DIR__ . '/texts/del_dup_fixed.txt';

$text = file_get_contents($file1);

$new_text = remove_Duplicate_refs($text);

file_put_contents($file2, $new_text);
