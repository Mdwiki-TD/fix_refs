<?php
/*
php I:\mdwiki\mdwiki\public_html\fixwikirefs\wprefs\tests\test_es_months.php
*/
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once __DIR__ . '/../include_files.php';

use function WpRefs\Bots\es_months\make_new_val;

$test_texts = [
    [
        "old" => "July 25, 1975",
        "new" => "25 de julio de 1975"
    ],
    [
        "old" => "November 2022",
        "new" => "noviembre de 2022"
    ],
    [
        "old" => "January, 2024",
        "new" => "enero de 2024"
    ],
    [
        "old" => "10 March, 2023",
        "new" => "10 de marzo de 2023"
    ],
];

foreach ($test_texts as $test) {
    $old = $test["old"];
    $new = $test["new"];

    $fixed_text = make_new_val($old);

    if ($fixed_text == $new) {
        echo "fixed okay!";
    } elseif ($fixed_text == $old) {
        echo "fixed_text == old text!";
    } else {
        echo "fixed error!:\n\n";
        echo $fixed_text;
    }
    echo "\n\n____________________\n\n";
}
